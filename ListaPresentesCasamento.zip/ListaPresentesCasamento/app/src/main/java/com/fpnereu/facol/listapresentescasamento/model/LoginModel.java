package com.fpnereu.facol.listapresentescasamento.model;

import android.util.Log;

import com.fpnereu.facol.listapresentescasamento.domain.ResponseManipulation;
import com.fpnereu.facol.listapresentescasamento.util.Http;
import com.fpnereu.facol.listapresentescasamento.util.HttpParam;
import com.google.gson.Gson;

public class LoginModel {

    private static final String URL_BASE = "http://fabiosantos.tk/aula_ws_presentes/Login";
    private static String result;

    public static boolean logar(String usuario, String senha){
        ResponseManipulation response;
        boolean ret = false;

        try{
            result = Http.post(URL_BASE, new HttpParam()
                    .add("usuario", usuario)
                    .add("senha", senha)
                    .getParam());

            response = new Gson().fromJson(result, ResponseManipulation.class);

            if (response != null && !response.isResponse()){
                ret = false;
            } else {
                ret = true;
            }
        }catch (Exception ex){
            Log.e("teste", ex.getMessage());
        } finally {
            response = null;
        }

        return ret;
    }
}
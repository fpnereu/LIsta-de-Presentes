package com.fpnereu.facol.listapresentescasamento;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.fpnereu.facol.listapresentescasamento.model.LoginModel;

public class ActivityLogin extends AppCompatActivity {

    private EditText txtUsuario;
    private EditText txtSenha;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__login);

        txtUsuario = findViewById(R.id.txtUsuario);
        txtSenha = findViewById(R.id.txtSenha);

    }

    public void login (View v){
        new Thread(new Runnable() {
            @Override
            public void run() {

                final boolean ret;
                final String usuario = txtUsuario.getText().toString();
                final String senha = txtSenha.getText().toString();

                if (usuario.length() == 0) {
                    Toast.makeText( ActivityLogin.this,"Usuario não pode ser vazio", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (senha.length() == 0) {
                    Toast.makeText( ActivityLogin.this,"Senha não pode ser vazio", Toast.LENGTH_SHORT).show();
                    return;
                }

                ret = LoginModel.logar(usuario, senha);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (ret){
                            Intent i = new Intent(ActivityLogin.this, MainActivity.class);
                            startActivity(i);
                        }else{
                            Toast.makeText( ActivityLogin.this,"Falha ao realizar login!", Toast.LENGTH_SHORT).show();
                            return;
                        }

                    }
                });
            }
        }).start();
    }
}

package com.fpnereu.facol.listapresentescasamento.domain;

import java.util.List;

public class ResponseListaPresente extends Response {

    private List<Presente> response;

    public ResponseListaPresente() {
    }

    public ResponseListaPresente(List<Presente> response) {
        this.response = response;
    }

    public List<Presente> getResponse() {
        return response;
    }

    public void setResponse(List<Presente> response) {
        this.response = response;
    }
}
